﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bondova.Model
{
    
    public abstract class ContainerTemp
    {
        public string ContianerName { get; set; }
    }
}
